# Ecommerce2021A-Thalis
Projeto usando C# web padrão MVC para criação de um E-commerce
